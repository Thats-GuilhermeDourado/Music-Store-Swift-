//
//  NearYouView.swift
//  trabalho
//
//  Created by formando on 11/09/2024.
//

import SwiftUI

struct NearYouView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    NearYouView()
}

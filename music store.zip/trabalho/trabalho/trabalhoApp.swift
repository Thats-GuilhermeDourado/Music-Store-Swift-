//
//  trabalhoApp.swift
//  trabalho
//
//  Created by formando on 11/09/2024.
//

import SwiftUI

@main
struct trabalhoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

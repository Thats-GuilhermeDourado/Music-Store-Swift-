//
//  NearYouData.swift
//  trabalho
//
//  Created by formando on 11/09/2024.
//

import Foundation

struct PlacesModel {
    var id: Int
    var name: String
    var time: String
    var rating: String
    var image: String
}

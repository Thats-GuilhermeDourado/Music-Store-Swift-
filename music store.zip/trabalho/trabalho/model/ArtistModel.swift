//
//  ArtistModel.swift
//  trabalho
//
//  Created by formando on 11/09/2024.
//

import SwiftUI

struct ArtistModel {
    let id: Int
    let name: String
    let image: String
}
